import cv2
import numpy as np
from PIL import Image
import torch
from ultralytics import YOLO
from transformers import pipeline
import io
import base64

class AIModelService:
    def __init__(self):
        # 初始化模型（首次运行会自动下载）
        self.yolo_model = None
        self.segmentation_model = None
        self.keypoint_model = None
        self._load_models()
    
    def _load_models(self):
        try:
            # YOLOv8目标检测模型
            self.yolo_model = YOLO('yolov8n.pt')  # nano版本，轻量级
            print("✅ YOLOv8 目标检测模型加载成功")
        except Exception as e:
            print(f"❌ YOLOv8 模型加载失败: {e}")
    
    def detect_objects(self, image_bytes):
        """边界框检测，返回 (标注列表, 标注后的图片Base64编码)"""
        if not self.yolo_model:
            # 如果模型未加载，返回模拟数据和空图片
            return [self._generate_mock_bbox()], None
        
        try:
            # 转换图片格式
            image = Image.open(io.BytesIO(image_bytes)).convert("RGB")
            img_np = np.array(image)
            
            # 运行推理
            results = self.yolo_model(image)
            
            annotations = []
            # 在图片上绘制
            draw_img = img_np.copy()

            for result in results:
                boxes = result.boxes
                if boxes is not None:
                    for box in boxes:
                        # 获取边界框坐标
                        x1, y1, x2, y2 = map(int, box.xyxy[0].tolist())
                        conf = box.conf[0].item()
                        cls = int(box.cls[0].item())
                        
                        # 获取类别名称
                        class_name = self.yolo_model.names[cls]
                        label = f"{class_name} ({conf:.2f})"

                        # 绘制边界框
                        cv2.rectangle(draw_img, (x1, y1), (x2, y2), (0, 255, 255), 2)
                        
                        # 绘制标签背景
                        (w, h), _ = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.6, 2)
                        cv2.rectangle(draw_img, (x1, y1 - 20), (x1 + w, y1), (0, 255, 255), -1)
                        # 绘制标签文字
                        cv2.putText(draw_img, label, (x1, y1 - 5), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 0), 2)

                        # 转换为百分比坐标用于JSON返回
                        img_w, img_h = image.size
                        x_percent = (x1 / img_w) * 100
                        y_percent = (y1 / img_h) * 100
                        w_percent = ((x2 - x1) / img_w) * 100
                        h_percent = ((y2 - y1) / img_h) * 100
                        
                        annotation = {
                            "from_name": "tag",
                            "to_name": "img",
                            "type": "rectanglelabels",
                            "value": {
                                "rectanglelabels": [label],
                                "x": x_percent,
                                "y": y_percent,
                                "width": w_percent,
                                "height": h_percent
                            }
                        }
                        annotations.append(annotation)
            
            # 将绘制后的图片转为Base64
            _, buffer = cv2.imencode('.jpg', cv2.cvtColor(draw_img, cv2.COLOR_RGB2BGR))
            annotated_image_base64 = base64.b64encode(buffer).decode('utf-8')

            return annotations, f"data:image/jpeg;base64,{annotated_image_base64}"
            
        except Exception as e:
            print(f"目标检测错误: {e}")
            return [self._generate_mock_bbox()], None
    
    def segment_objects(self, image_bytes):
        """多边形分割"""
        # 这里可以集成SAM (Segment Anything Model) 或其他分割模型
        # 暂时返回模拟数据
        return [self._generate_mock_polygon()]
    
    def detect_keypoints(self, image_bytes):
        """关键点检测"""
        # 这里可以集成人体姿态估计模型
        # 暂时返回模拟数据
        return [self._generate_mock_keypoint()]
    
    def _generate_mock_bbox(self):
        """生成模拟边界框"""
        return {
            "from_name": "tag",
            "to_name": "img",
            "type": "rectanglelabels",
            "value": {
                "rectanglelabels": ["未检测到对象"],
                "x": 10,
                "y": 15,
                "width": 20,
                "height": 25
            }
        }
    
    def _generate_mock_polygon(self):
        """生成模拟多边形"""
        return {
            "from_name": "tag",
            "to_name": "img",
            "type": "polygonlabels",
            "value": {
                "polygonlabels": ["分割区域"],
                "points": [[20, 20], [50, 20], [50, 50], [20, 50]]
            }
        }
    
    def _generate_mock_keypoint(self):
        """生成模拟关键点"""
        return {
            "from_name": "tag",
            "to_name": "img",
            "type": "keypointlabels",
            "value": {
                "keypointlabels": ["关键点"],
                "x": 35,
                "y": 40
            }
        }

# 全局模型实例
ai_service = AIModelService()