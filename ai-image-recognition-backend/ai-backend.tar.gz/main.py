from fastapi import FastAPI, File, UploadFile, Form, HTTPException, Depends
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import create_engine, Column, Integer, String, DateTime, JSON, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, Session, relationship
from datetime import datetime
import uuid

# 导入AI模型服务
from ai_models import ai_service

# 数据库配置
DATABASE_URL = "sqlite:///./auto_annotate.db"
engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

# 数据库模型
class Image(Base):
    __tablename__ = "images"
    id = Column(Integer, primary_key=True, index=True)
    filename = Column(String, unique=True, index=True)
    uploaded_at = Column(DateTime, default=datetime.utcnow)
    annotations = relationship("AutoAnnotation", back_populates="image")
    manual_annotations = relationship("ManualAnnotation", back_populates="image")

class AutoAnnotation(Base):
    __tablename__ = "auto_annotations"
    id = Column(Integer, primary_key=True, index=True)
    image_id = Column(Integer, ForeignKey("images.id"))
    tool_type = Column(String)
    annotation_data = Column(JSON)
    created_at = Column(DateTime, default=datetime.utcnow)
    image = relationship("Image", back_populates="annotations")

class ManualAnnotation(Base):
    __tablename__ = "manual_annotations"
    id = Column(Integer, primary_key=True, index=True)
    image_id = Column(Integer, ForeignKey("images.id"))
    tool_type = Column(String)
    annotation_data = Column(JSON)
    created_at = Column(DateTime, default=datetime.utcnow)
    image = relationship("Image", back_populates="manual_annotations")

# 创建数据库表
Base.metadata.create_all(bind=engine)

# 创建FastAPI应用
app = FastAPI()

# 添加CORS中间件
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 导入并包含训练API路由
from training.api import router as training_router
app.include_router(training_router)

# Dependency to get DB session
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@app.get("/api/tools")
async def get_tools():
    """返回可用的AI标注工具列表"""
    tools = [
        {"value": "bbox", "label": "边界框检测"},
        {"value": "polygon", "label": "多边形分割"},
        {"value": "keypoint", "label": "关键点检测"}
    ]
    return JSONResponse(content=tools)

def generate_bbox_annotation():
    return {
        "from_name": "tag",
        "to_name": "img",
        "type": "rectanglelabels",
        "value": {
            "rectanglelabels": ["Object"],
            "x": 10,
            "y": 15,
            "width": 20,
            "height": 25
        }
    }

def generate_polygon_annotation():
    return {
        "from_name": "tag",
        "to_name": "img",
        "type": "polygonlabels",
        "value": {
            "polygonlabels": ["Area"],
            "points": [[20, 20], [50, 20], [50, 50], [20, 50]]
        }
    }

def generate_keypoint_annotation():
    return {
        "from_name": "tag",
        "to_name": "img",
        "type": "keypointlabels",
        "value": {
            "keypointlabels": ["Point"],
            "x": 35,
            "y": 40
        }
    }

@app.post("/api/auto_annotate")
async def auto_annotate(image: UploadFile = File(...), tool: str = Form(...), db: Session = Depends(get_db)):
    try:
        # 1. 读取图片数据
        image_bytes = await image.read()
        
        # 2. 保存图片信息到数据库
        db_image = db.query(Image).filter(Image.filename == image.filename).first()
        if not db_image:
            db_image = Image(filename=image.filename)
            db.add(db_image)
            db.commit()
            db.refresh(db_image)

        # 3. 使用AI模型生成标注
        annotations = []
        annotated_image_base64 = None
        if tool == "bbox":
            annotations, annotated_image_base64 = ai_service.detect_objects(image_bytes)
        elif tool == "polygon":
            annotations = ai_service.segment_objects(image_bytes) # 保持不变，因为只实现了bbox的可视化
        elif tool == "keypoint":
            annotations = ai_service.detect_keypoints(image_bytes) # 保持不变
        else:
            raise HTTPException(status_code=400, detail=f"Tool type '{tool}' is not supported.")

        # 4. 保存所有标注到数据库
        for annotation in annotations:
            db_annotation = AutoAnnotation(
                image_id=db_image.id,
                tool_type=tool,
                annotation_data=annotation
            )
            db.add(db_annotation)
        
        db.commit()

        # 5. 封装响应数据
        response_data = {
            "annotations": [
                {
                    "result": annotations
                }
            ],
            "annotated_image": annotated_image_base64, # 添加标注后的图片
            "database_info": {
                "image_id": db_image.id,
                "annotation_count": len(annotations)
            }
        }

        return JSONResponse(content=response_data)

    except Exception as e:
        db.rollback()
        return JSONResponse(
            status_code=500,
            content={"detail": f"Error processing image: {str(e)}"}
        )

# 添加手动标注提交API
@app.post("/api/annotations")
async def submit_annotation(annotation_data: dict, db: Session = Depends(get_db)):
    try:
        # 根据图片名称查找图片
        image_name = annotation_data.get('imageName')
        tool_type = annotation_data.get('tool')
        annotation = annotation_data.get('annotation')
        
        if not all([image_name, tool_type, annotation]):
            raise HTTPException(status_code=400, detail="Missing required fields")
        
        # 查找或创建图片记录
        db_image = db.query(Image).filter(Image.filename == image_name).first()
        if not db_image:
            db_image = Image(filename=image_name)
            db.add(db_image)
            db.commit()
            db.refresh(db_image)
        
        # 保存手动标注
        db_annotation = ManualAnnotation(
            image_id=db_image.id,
            tool_type=tool_type,
            annotation_data=annotation
        )
        db.add(db_annotation)
        db.commit()
        db.refresh(db_annotation)
        
        return JSONResponse(content={
            "message": "Annotation saved successfully",
            "annotation_id": db_annotation.id,
            "image_id": db_image.id
        })
        
    except Exception as e:
        db.rollback()
        return JSONResponse(
            status_code=500,
            content={"detail": f"Error saving annotation: {str(e)}"}
        )

# 获取图片的所有标注
@app.get("/api/images/{image_id}/annotations")
async def get_image_annotations(image_id: int, db: Session = Depends(get_db)):
    try:
        db_image = db.query(Image).filter(Image.id == image_id).first()
        if not db_image:
            raise HTTPException(status_code=404, detail="Image not found")
        
        auto_annotations = db.query(AutoAnnotation).filter(AutoAnnotation.image_id == image_id).all()
        manual_annotations = db.query(ManualAnnotation).filter(ManualAnnotation.image_id == image_id).all()
        
        return JSONResponse(content={
            "image_id": image_id,
            "filename": db_image.filename,
            "auto_annotations": [{
                "id": ann.id,
                "tool_type": ann.tool_type,
                "annotation_data": ann.annotation_data,
                "created_at": ann.created_at.isoformat()
            } for ann in auto_annotations],
            "manual_annotations": [{
                "id": ann.id,
                "tool_type": ann.tool_type,
                "annotation_data": ann.annotation_data,
                "created_at": ann.created_at.isoformat()
            } for ann in manual_annotations]
        })
        
    except Exception as e:
        return JSONResponse(
            status_code=500,
            content={"detail": f"Error retrieving annotations: {str(e)}"}
        )

@app.get("/")
def read_root():
    return {"message": "AI Auto-Annotation Backend is running."}