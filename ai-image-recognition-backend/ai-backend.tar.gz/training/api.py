from fastapi import APIRouter, HTTPException, Depends
from typing import List, Optional
from pydantic import BaseModel

from .training_service import (
    training_service, 
    TrainingConfig, 
    TrainingType, 
    TrainingStatus
)

router = APIRouter(prefix="/api/training", tags=["training"])


class TrainingConfigRequest(BaseModel):
    """训练配置请求模型"""
    task: str = "detect"
    model_type: str = "s"
    data_path: str
    epochs: int = 50
    imgsz: int = 640
    batch: int = 8
    project: str = "runs/train"
    name: Optional[str] = None
    resume_weights: Optional[str] = None
    patience: int = 15
    use_freeze_strategy: bool = True
    min_epochs_per_stage: int = 15


class IncrementalTrainingRequest(TrainingConfigRequest):
    """增量训练请求模型"""
    base_model_path: str
    new_classes: List[str]


class TrainingTaskResponse(BaseModel):
    """训练任务响应模型"""
    task_id: str
    training_type: str
    status: str
    created_at: str
    started_at: Optional[str] = None
    completed_at: Optional[str] = None
    progress: float
    current_epoch: int
    total_epochs: int
    error_message: Optional[str] = None
    result_path: Optional[str] = None
    metrics: dict = {}


@router.post("/regular", response_model=dict)
async def start_regular_training(config: TrainingConfigRequest):
    """启动常规训练"""
    try:
        training_config = TrainingConfig(**config.dict())
        task_id = training_service.create_task(TrainingType.REGULAR, training_config)
        
        if training_service.start_task(task_id):
            return {"task_id": task_id, "message": "训练任务已启动"}
        else:
            raise HTTPException(status_code=400, detail="启动训练任务失败")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"创建训练任务失败: {str(e)}")


@router.post("/incremental", response_model=dict)
async def start_incremental_training(config: IncrementalTrainingRequest):
    """启动增量训练"""
    try:
        training_config = TrainingConfig(**config.dict())
        task_id = training_service.create_task(TrainingType.INCREMENTAL, training_config)
        
        if training_service.start_task(task_id):
            return {"task_id": task_id, "message": "增量训练任务已启动"}
        else:
            raise HTTPException(status_code=400, detail="启动增量训练任务失败")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"创建增量训练任务失败: {str(e)}")


@router.post("/freeze-strategy", response_model=dict)
async def start_freeze_strategy_training(config: TrainingConfigRequest):
    """启动冻结策略训练"""
    try:
        training_config = TrainingConfig(**config.dict())
        task_id = training_service.create_task(TrainingType.FREEZE_STRATEGY, training_config)
        
        if training_service.start_task(task_id):
            return {"task_id": task_id, "message": "冻结策略训练任务已启动"}
        else:
            raise HTTPException(status_code=400, detail="启动冻结策略训练任务失败")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"创建冻结策略训练任务失败: {str(e)}")


@router.get("/tasks", response_model=List[TrainingTaskResponse])
async def get_all_tasks():
    """获取所有训练任务"""
    tasks = training_service.get_all_tasks()
    return [TrainingTaskResponse(**task.to_dict()) for task in tasks]


@router.get("/tasks/{task_id}", response_model=TrainingTaskResponse)
async def get_task(task_id: str):
    """获取指定训练任务"""
    task = training_service.get_task(task_id)
    if not task:
        raise HTTPException(status_code=404, detail="训练任务不存在")
    return TrainingTaskResponse(**task.to_dict())


@router.get("/tasks/{task_id}/logs")
async def get_task_logs(task_id: str):
    """获取训练任务日志"""
    task = training_service.get_task(task_id)
    if not task:
        raise HTTPException(status_code=404, detail="训练任务不存在")
    return {"logs": task.logs}


@router.post("/tasks/{task_id}/cancel")
async def cancel_task(task_id: str):
    """取消训练任务"""
    if training_service.cancel_task(task_id):
        return {"message": "训练任务已取消"}
    else:
        raise HTTPException(status_code=400, detail="无法取消训练任务")


@router.get("/status")
async def get_training_status():
    """获取训练服务状态"""
    tasks = training_service.get_all_tasks()
    running_count = sum(1 for task in tasks if task.status == TrainingStatus.RUNNING)
    completed_count = sum(1 for task in tasks if task.status == TrainingStatus.COMPLETED)
    failed_count = sum(1 for task in tasks if task.status == TrainingStatus.FAILED)
    
    return {
        "total_tasks": len(tasks),
        "running_tasks": running_count,
        "completed_tasks": completed_count,
        "failed_tasks": failed_count,
        "service_status": "running"
    }