import os
import torch
import datetime
import yaml
import time
from pathlib import Path
from ultralytics import YOLO
from typing import Optional, Dict, Any, List


def count_samples(data_path: str, task: str = 'detect') -> int:
    """
    统计训练数据的样本数量。
    - 对分类任务，统计 train 和 val 文件夹下所有文件数量。
    - 对检测/分割任务，从 yaml 配置文件中读取 train 路径，统计图像数量。
    """
    if task == 'classify':
        train_dir = os.path.join(data_path, 'train')
        val_dir = os.path.join(data_path, 'val')
        train_count = sum(len(files) for _, _, files in os.walk(train_dir)) if os.path.exists(train_dir) else 0
        val_count = sum(len(files) for _, _, files in os.walk(val_dir)) if os.path.exists(val_dir) else 0
        return train_count + val_count
    else:
        try:
            with open(data_path, 'r', encoding='utf-8') as f:
                data_cfg = yaml.safe_load(f)
            img_dir = data_cfg.get('train')
            if isinstance(img_dir, list):
                return sum(len(os.listdir(p)) for p in img_dir if os.path.exists(p))
            elif isinstance(img_dir, str):
                return len(os.listdir(img_dir)) if os.path.exists(img_dir) else 0
        except Exception as e:
            print(f"⚠️ 统计样本数量失败: {str(e)}")
            return 0


def is_training_finished(model_path: str) -> bool:
    """
    检查模型是否已完成训练
    """
    if not os.path.exists(model_path):
        return False
    
    try:
        model = YOLO(model_path)
        # 检查模型是否有训练历史
        return hasattr(model, 'trainer') and model.trainer is not None
    except Exception:
        return False


def load_class_names_from_yaml(yaml_path: str) -> List[str]:
    """
    从YAML配置文件中加载类别名称
    """
    try:
        with open(yaml_path, 'r', encoding='utf-8') as f:
            data = yaml.safe_load(f)
        return data.get('names', [])
    except Exception as e:
        print(f"⚠️ 加载类别名称失败: {str(e)}")
        return []


def train_incremental_model(
    base_model_path: Optional[str] = None,  # 改为base_model_path
    data_yaml_path: str = "data.yaml",     # 改为data_yaml_path
    new_classes: Optional[List[str]] = None, # 添加new_classes参数
    task: str = 'detect',
    model_type: str = 's',
    epochs: int = 50,
    imgsz: int = 640,
    batch: int = 8,
    project: str = 'runs/incremental',
    name: Optional[str] = None,
    patience: int = 15,
    use_freeze_strategy: bool = True,
    freeze_epochs: int = 10,
    progress_callback: Optional[callable] = None  # 添加进度回调
) -> Dict[str, Any]:
    """增量训练主函数"""
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    print(f"🖥️ 使用设备: {device}")
    
    # 构建训练结果保存名称
    timestamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
    if name is None:
        name = f'incremental_{task}_{model_type}_{timestamp}'
    
    # 创建训练目录
    train_dir = os.path.join(project, name)
    os.makedirs(train_dir, exist_ok=True)
    
    # 统计训练样本数量
    sample_count = count_samples(data_yaml_path, task)
    print(f"✅ 检测到样本数量：{sample_count}")
    
    # 选择模型路径
    if base_model_path and os.path.exists(base_model_path):
        model_path = base_model_path
        print(f"📁 使用现有权重: {base_model_path}")
    else:
        # 使用预训练模型
        if task == 'classify':
            model_path = f'yolov8{model_type}-cls.pt'
        elif task == 'segment':
            model_path = f'yolov8{model_type}-seg.pt'
        else:
            model_path = f'yolov8{model_type}.pt'
        print(f"📁 使用预训练模型: {model_path}")
    
    # 加载模型
    model = YOLO(model_path)
    
    # 检查是否需要处理新类别
    if new_classes:
        print(f"🆕 检测到 {len(new_classes)} 个新类别: {new_classes}")
    
    try:
        # 开始训练
        print(f"🚀 开始增量训练...")
        
        # 自定义训练回调
        def on_epoch_end(trainer):
            if progress_callback:
                progress_callback(trainer.epoch + 1, epochs)
        
        # 执行训练
        results = model.train(
            data=data_yaml_path,
            epochs=epochs,
            imgsz=imgsz,
            batch=batch,
            project=project,
            name=name,
            patience=patience,
            device=device,
            verbose=True
        )
        
        # 保存训练配置
        config = {
            'task': task,
            'model_type': model_type,
            'data_path': data_path,
            'existing_weights_path': existing_weights_path,
            'epochs': epochs,
            'imgsz': imgsz,
            'batch': batch,
            'sample_count': sample_count,
            'new_classes': new_classes,
            'device': device,
            'timestamp': timestamp
        }
        
        config_path = os.path.join(train_dir, 'incremental_config.yaml')
        with open(config_path, 'w', encoding='utf-8') as f:
            yaml.dump(config, f, default_flow_style=False, allow_unicode=True)
        
        # 尝试导出ONNX模型
        try:
            export_path = os.path.join(train_dir, 'model.onnx')
            model.export(format='onnx', dynamic=True, simplify=True, imgsz=imgsz)
            print(f"✅ ONNX 模型已导出")
        except Exception as e:
            print(f"⚠️ ONNX 导出失败: {str(e)}")
        
        print(f"\n🎉 增量训练完成！")
        print(f"📁 结果保存至：{train_dir}")
        print(f"📄 配置文件：{config_path}")
        
        return {
            'success': True,
            'train_dir': train_dir,
            'config': config,
            'results': results,
            'message': '增量训练完成'
        }
        
    except Exception as e:
        error_msg = f"增量训练失败: {str(e)}"
        print(f"❌ {error_msg}")
        return {
            'success': False,
            'error': error_msg,
            'train_dir': train_dir
        }