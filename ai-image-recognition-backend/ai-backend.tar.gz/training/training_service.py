import os
import uuid
import asyncio
import threading
from datetime import datetime
from typing import Dict, List, Optional, Any
from enum import Enum
from dataclasses import dataclass, asdict
import json
from pathlib import Path

from .incremental_training import train_incremental_model
from .enhanced_training import train_model_with_enhanced_freeze, get_model_size_from_type


class TrainingStatus(Enum):
    """训练状态枚举"""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class TrainingType(Enum):
    """训练类型枚举"""
    REGULAR = "regular"
    INCREMENTAL = "incremental"
    FREEZE_STRATEGY = "freeze_strategy"


@dataclass
class TrainingConfig:
    """训练配置"""
    task: str = "detect"  # detect, segment, classify
    model_type: str = "s"  # n, s, m, l, x
    data_path: str = "data.yaml"
    epochs: int = 50
    imgsz: int = 640
    batch: int = 8
    project: str = "runs/train"
    name: Optional[str] = None
    resume_weights: Optional[str] = None
    patience: int = 15
    use_freeze_strategy: bool = True
    min_epochs_per_stage: int = 15
    # 增量训练特有参数
    base_model_path: Optional[str] = None
    new_classes: Optional[List[str]] = None
    
    def to_dict(self):
        return asdict(self)


@dataclass
class TrainingTask:
    """训练任务"""
    task_id: str
    training_type: TrainingType
    config: TrainingConfig
    status: TrainingStatus = TrainingStatus.PENDING
    created_at: datetime = None
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    progress: float = 0.0
    current_epoch: int = 0
    total_epochs: int = 0
    logs: List[str] = None
    error_message: Optional[str] = None
    result_path: Optional[str] = None
    metrics: Dict[str, Any] = None
    
    def __post_init__(self):
        if self.created_at is None:
            self.created_at = datetime.now()
        if self.logs is None:
            self.logs = []
        if self.metrics is None:
            self.metrics = {}
    
    def to_dict(self):
        data = asdict(self)
        # 转换枚举为字符串
        data['training_type'] = self.training_type.value
        data['status'] = self.status.value
        # 转换datetime为字符串
        for field in ['created_at', 'started_at', 'completed_at']:
            if data[field]:
                data[field] = data[field].isoformat()
        return data


class TrainingService:
    """训练服务管理类"""
    
    def __init__(self):
        self.tasks: Dict[str, TrainingTask] = {}
        self.running_tasks: Dict[str, threading.Thread] = {}
        
    def create_task(self, training_type: TrainingType, config: TrainingConfig) -> str:
        """创建训练任务"""
        task_id = str(uuid.uuid4())
        task = TrainingTask(
            task_id=task_id,
            training_type=training_type,
            config=config,
            total_epochs=config.epochs
        )
        self.tasks[task_id] = task
        return task_id
    
    def get_task(self, task_id: str) -> Optional[TrainingTask]:
        """获取训练任务"""
        return self.tasks.get(task_id)
    
    def get_all_tasks(self) -> List[TrainingTask]:
        """获取所有训练任务"""
        return list(self.tasks.values())
    
    def start_task(self, task_id: str) -> bool:
        """启动训练任务"""
        task = self.tasks.get(task_id)
        if not task or task.status != TrainingStatus.PENDING:
            return False
        
        task.status = TrainingStatus.RUNNING
        task.started_at = datetime.now()
        
        # 在新线程中执行训练
        thread = threading.Thread(target=self._run_training, args=(task,))
        thread.daemon = True
        self.running_tasks[task_id] = thread
        thread.start()
        
        return True
    
    def cancel_task(self, task_id: str) -> bool:
        """取消训练任务"""
        task = self.tasks.get(task_id)
        if not task or task.status not in [TrainingStatus.PENDING, TrainingStatus.RUNNING]:
            return False
        
        task.status = TrainingStatus.CANCELLED
        task.completed_at = datetime.now()
        
        # 如果任务正在运行，尝试停止线程（注意：Python线程无法强制停止）
        if task_id in self.running_tasks:
            del self.running_tasks[task_id]
        
        return True
    
    def _run_training(self, task: TrainingTask):
        """执行训练任务"""
        try:
            self._log_message(task, f"开始训练任务: {task.task_id}")
            
            if task.training_type == TrainingType.INCREMENTAL:
                result = self._run_incremental_training(task)
            elif task.training_type == TrainingType.FREEZE_STRATEGY:
                result = self._run_freeze_strategy_training(task)
            else:
                result = self._run_regular_training(task)
            
            if result:
                task.status = TrainingStatus.COMPLETED
                task.result_path = result.get('model_path')
                task.metrics = result.get('metrics', {})
                self._log_message(task, f"训练完成，模型保存至: {task.result_path}")
            else:
                task.status = TrainingStatus.FAILED
                task.error_message = "训练失败，未返回结果"
                
        except Exception as e:
            task.status = TrainingStatus.FAILED
            task.error_message = str(e)
            self._log_message(task, f"训练失败: {str(e)}")
        
        finally:
            task.completed_at = datetime.now()
            task.progress = 100.0
            if task.task_id in self.running_tasks:
                del self.running_tasks[task.task_id]
    
    def _run_incremental_training(self, task: TrainingTask) -> Optional[Dict]:
        """执行增量训练"""
        config = task.config
        
        def progress_callback(epoch, total_epochs):
            task.current_epoch = epoch
            task.progress = (epoch / total_epochs) * 100
            self._log_message(task, f"训练进度: {epoch}/{total_epochs} ({task.progress:.1f}%)")
        
        result = train_incremental_model(
            base_model_path=config.base_model_path,
            data_yaml_path=config.data_path,
            new_classes=config.new_classes,
            task=config.task,
            model_type=config.model_type,
            epochs=config.epochs,
            imgsz=config.imgsz,
            batch=config.batch,
            project=config.project,
            name=config.name,
            patience=config.patience,
            progress_callback=progress_callback
        )
        
        return result
    
    def _run_freeze_strategy_training(self, task: TrainingTask) -> Optional[Dict]:
        """执行冻结策略训练"""
        config = task.config
        
        def progress_callback(epoch, total_epochs):
            task.current_epoch = epoch
            task.progress = (epoch / total_epochs) * 100
            self._log_message(task, f"训练进度: {epoch}/{total_epochs} ({task.progress:.1f}%)")
        
        result = train_model_with_enhanced_freeze(
            task=config.task,
            model_type=config.model_type,
            data_path=config.data_path,
            epochs=config.epochs,
            imgsz=config.imgsz,
            batch=config.batch,
            project=config.project,
            name=config.name,
            resume_weights=config.resume_weights,
            patience=config.patience,
            use_freeze_strategy=config.use_freeze_strategy,
            min_epochs_per_stage=config.min_epochs_per_stage,
            progress_callback=progress_callback
        )
        
        return result
    
    def _run_regular_training(self, task: TrainingTask) -> Optional[Dict]:
        """执行常规训练"""
        config = task.config
        
        def progress_callback(epoch, total_epochs):
            task.current_epoch = epoch
            task.progress = (epoch / total_epochs) * 100
            self._log_message(task, f"训练进度: {epoch}/{total_epochs} ({task.progress:.1f}%)")
        
        # 使用冻结策略训练但禁用冻结功能
        result = train_model_with_enhanced_freeze(
            task=config.task,
            model_type=config.model_type,
            data_path=config.data_path,
            epochs=config.epochs,
            imgsz=config.imgsz,
            batch=config.batch,
            project=config.project,
            name=config.name,
            resume_weights=config.resume_weights,
            patience=config.patience,
            use_freeze_strategy=False,  # 禁用冻结策略
            progress_callback=progress_callback
        )
        
        return result
    
    def _log_message(self, task: TrainingTask, message: str):
        """记录日志消息"""
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log_entry = f"[{timestamp}] {message}"
        task.logs.append(log_entry)
        print(log_entry)  # 同时输出到控制台


# 全局训练服务实例
training_service = TrainingService()