# AI 图像自动标注后端服务

这是一个基于 FastAPI 的后端服务，为 AI 图像识别与标注平台提供核心支持。它使用 YOLOv8 模型进行对象检测，并通过 API 接口与前端应用进行交互。数据存储在 SQLite 数据库中。

## 📂 项目结构

```
.
├── auto_annotate.db      # SQLite 数据库文件
├── main.py               # FastAPI 应用主文件
├── requirements.txt      # Python 依赖项
└── README.md             # 项目说明文档
```

## 如何运行

我们推荐使用 VS Code 的任务（Tasks）功能来实现一键启动，这比每次手动输入命令要方便得多。

### 步骤一：安装依赖

如果您是首次运行此项目，或者依赖项有更新，请先在终端中运行以下命令安装所有必需的 Python 包：

```bash
pip install -r requirements.txt
```

### 步骤二：启动服务

您有两种方式启动服务：

#### 方式一：使用 VS Code 任务（推荐）

本仓库没有包含 VS Code 的配置 (`.vscode/tasks.json`)，但您可以手动创建它来实现一键启动：

1.  在项目根目录下创建一个名为 `.vscode` 的文件夹。
2.  在 `.vscode` 文件夹中创建一个名为 `tasks.json` 的文件。
3.  将以下内容复制到 `tasks.json` 文件中：

    ```json
    {
        "version": "2.0.0",
        "tasks": [
            {
                "label": "Run FastAPI Server",
                "type": "shell",
                "command": "uvicorn main:app --reload --port 8000",
                "problemMatcher": [],
                "presentation": {
                    "reveal": "always",
                    "panel": "new"
                },
                "group": {
                    "kind": "build",
                    "isDefault": true
                }
            }
        ]
    }
    ```

4.  **如何运行任务**：
    *   按下快捷键 `Ctrl+Shift+B` (这是运行默认构建任务的快捷键)。
    *   或者，通过菜单栏 `Terminal` -> `Run Task...`，然后选择 `Run FastAPI Server`。

    服务将在一个新的终端面板中启动。

#### 方式二：手动输入命令

在项目根目录打开终端，然后运行以下命令：

```bash
uvicorn main:app --reload --port 8000
```

### 验证服务

服务启动后，您可以在浏览器中访问 [http://127.0.0.1:8000/docs](http://127.0.0.1:8000/docs) 来查看和测试 API 文档。

## API 接口

### `POST /api/auto_annotate`

此接口用于上传图片并获取自动标注结果。

-   **请求体** (`multipart/form-data`):
    -   `image`: 图片文件 (`UploadFile`)
    -   `tool`: 标注工具类型 (`str`)，可选值为 `bbox`, `polygon`, `keypoint`。
-   **成功响应** (HTTP 200):
    -   返回 Label Studio 格式的 JSON 标注结果，并包含数据库存储信息。
-   **失败响应** (HTTP 500):
    -   返回错误详情。